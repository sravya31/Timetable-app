package com.example.sravyanaguboyina.timetable;

/**
 * Created by sravya naguboyina on 08-10-2017.
 */
import android.net.Uri;
public class PDFDoc {
    String name,path;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
